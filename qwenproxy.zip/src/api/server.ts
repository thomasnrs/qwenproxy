import { Hono } from 'hono'
import { serve } from '@hono/node-server'
import { config } from '../core/config.js'
import { metrics } from '../core/metrics.js'
import { MemoryCache } from '../cache/memory-cache.js'
import { Watchdog } from '../core/watchdog.js'
import { app as modelsApp } from './models.js'
import { chatCompletions, chatCompletionsStop } from '../routes/chat.js'
import { openRouterApp } from '../openrouterproxy/router.js'
import { qwenParallelApp } from '../qwenparallel/router.js'
import { deepSeekApp } from '../deepseek/router.js'
import { chatGPTApp } from '../chatgpt/router.js'
import { claudeApp } from '../claude/router.js'

const app = new Hono()
app.route('', modelsApp)
app.post('/v1/chat/completions', chatCompletions)
app.post('/v1/chat/completions/stop', chatCompletionsStop)
// OpenRouter passthrough proxy with multi-key rotation (separate path prefix so
// it never collides with the Qwen routes above).
app.route('/openrouter', openRouterApp)
// Mutex-free Qwen entrypoint: many concurrent streams per account (fresh chat
// per request). Separate path prefix; shares the account pool but none of the
// main route's code.
app.route('/qwen-parallel', qwenParallelApp)
// DeepSeek via Playwright (chat.deepseek.com), separate account pool.
app.route('/deepseek', deepSeekApp)
// ChatGPT via Playwright (chatgpt.com), separate account pool.
app.route('/chatgpt', chatGPTApp)
// Claude via Playwright (claude.ai), separate account pool.
app.route('/claude', claudeApp)

let cache: MemoryCache
let watchdog: Watchdog
let server: any
let cooldownSync: NodeJS.Timeout | null = null

app.use('*', async (c, next) => {
  metrics.increment('requests.total')
  const start = Date.now()
  await next()
  const duration = Date.now() - start
  metrics.histogram('latency.request', duration)
  c.header('X-Response-Time', `${duration}ms`)
})

app.use('/v1/*', async (c, next) => {
  const apiKey = process.env.API_KEY || config.apiKey
  if (apiKey) {
    const auth = c.req.header('Authorization')
    if (!auth?.startsWith('Bearer ')) {
      return c.json({ error: 'Missing or invalid Authorization header' }, 401)
    }
    const token = auth.slice(7)
    if (token !== apiKey) {
      return c.json({ error: 'Invalid API key' }, 401)
    }
  }
  await next()
})

app.get('/health', async (c) => {
  const status = await watchdog?.getStatus()
  return c.json({
    status: status?.overall || 'unknown',
    timestamp: Date.now(),
    metrics: {
      cache: await cache?.getStats(),
    },
  })
})

app.get('/metrics', (c) => {
  return c.text(metrics.formatPrometheus(), {
    headers: { 'Content-Type': 'text/plain; version=0.0.4' },
  })
})

app.onError((err, c) => {
  metrics.increment('requests.errors')
  console.error('API Error:', err)
  return c.json({ error: err.message }, 500)
})

app.notFound((c) => c.json({ error: 'Not found' }, 404))

export async function startServer(): Promise<void> {
  cache = new MemoryCache()
  await cache.connect()

  const { loadAccounts } = await import('../core/accounts.ts')
  const accounts = loadAccounts()

  if (accounts.length > 0) {
    console.log(`[Server] Pre-warming ${accounts.length} configured account(s)...`)
    const { initPlaywrightForAccount } = await import('../services/playwright.ts')
    const { getAccountCooldownInfo } = await import('../core/account-manager.ts')
    for (const account of accounts) {
      const cooldown = getAccountCooldownInfo(account.id)
      if (cooldown) {
        const mins = Math.round(cooldown.remainingMs / 60000)
        console.log(`[Server] Skipping pre-warm for ${account.email} — on cooldown for ~${mins}min (${cooldown.reason}). Will init lazily when cooldown expires.`)
        continue
      }
      try {
        await initPlaywrightForAccount(account, config.browser.headless)
      } catch (err: any) {
        console.error(`[Server] Failed to initialize account ${account.email}:`, err.message)
      }
    }
  } else {
    const { initPlaywright } = await import('../services/playwright.ts')
    await initPlaywright(config.browser.headless)
  }

  // Pre-warm DeepSeek accounts (separate pool / browser profiles).
  const { loadDeepSeekAccounts } = await import('../deepseek/accounts.ts')
  const deepSeekAccounts = loadDeepSeekAccounts()
  if (deepSeekAccounts.length > 0) {
    console.log(`[Server] Pre-warming ${deepSeekAccounts.length} DeepSeek account(s)...`)
    const { initDeepSeekAccount } = await import('../deepseek/browser.ts')
    for (const account of deepSeekAccounts) {
      try {
        await initDeepSeekAccount(account, config.browser.headless)
      } catch (err: any) {
        console.error(`[Server] Failed to initialize DeepSeek account ${account.email}:`, err.message)
      }
    }
  }

  // Pre-warm ChatGPT accounts (separate pool / browser profiles).
  const { loadChatGPTAccounts } = await import('../chatgpt/accounts.ts')
  const chatGPTAccounts = loadChatGPTAccounts()
  if (chatGPTAccounts.length > 0) {
    console.log(`[Server] Pre-warming ${chatGPTAccounts.length} ChatGPT account(s)...`)
    const { initChatGPTAccount } = await import('../chatgpt/browser.ts')
    for (const account of chatGPTAccounts) {
      try {
        await initChatGPTAccount(account, config.browser.headless)
      } catch (err: any) {
        console.error(`[Server] Failed to initialize ChatGPT account ${account.email}:`, err.message)
      }
    }
  }

  // Pre-warm Claude accounts (separate pool / browser profiles).
  const { loadClaudeAccounts } = await import('../claude/accounts.ts')
  const claudeAccounts = loadClaudeAccounts()
  if (claudeAccounts.length > 0) {
    console.log(`[Server] Pre-warming ${claudeAccounts.length} Claude account(s)...`)
    const { initClaudeAccount } = await import('../claude/browser.ts')
    for (const account of claudeAccounts) {
      try {
        await initClaudeAccount(account, config.browser.headless)
      } catch (err: any) {
        console.error(`[Server] Failed to initialize Claude account ${account.email}:`, err.message)
      }
    }
  }

  watchdog = new Watchdog()
  watchdog.start()

  metrics.startCollection()

  // Pick up cooldown changes made out-of-process (e.g. disabling an account via
  // `npm run login`) without a restart. The DB is the source of truth.
  const { reloadCooldownsFromDb } = await import('../core/account-manager.ts')
  cooldownSync = setInterval(() => reloadCooldownsFromDb(), 10000)

  // Interactive admin console (disable/enable accounts live). No-op when stdin
  // is not a TTY.
  const { startAdminConsole } = await import('../core/admin-console.ts')
  startAdminConsole()

  server = serve({
    fetch: app.fetch,
    port: config.server.port,
    hostname: config.server.host,
  }, (info) => {
    console.log(`Server listening on http://${info.address}:${info.port}`)
  })

  const shutdown = async (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`)
    watchdog.stop()
    metrics.stopCollection()
    if (cooldownSync) { clearInterval(cooldownSync); cooldownSync = null }
    const { stopAdminConsole } = await import('../core/admin-console.ts')
    stopAdminConsole()
    await cache.close()
    const { closePlaywright } = await import('../services/playwright.js')
    await closePlaywright()
    const { closeAllDeepSeek } = await import('../deepseek/browser.ts')
    await closeAllDeepSeek()
    const { closeAllChatGPT } = await import('../chatgpt/browser.ts')
    await closeAllChatGPT()
    const { closeAllClaude } = await import('../claude/browser.ts')
    await closeAllClaude()
    const { closeDatabase } = await import('../core/database.ts')
    closeDatabase()
    server?.close()
    process.exit(0)
  }

  process.on('SIGINT', () => shutdown('SIGINT'))
  process.on('SIGTERM', () => shutdown('SIGTERM'))
}

export { app }
