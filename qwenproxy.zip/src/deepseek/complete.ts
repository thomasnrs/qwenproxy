/*
 * DeepSeek proxy — completion via UI driving + stream tee.
 *
 * Per request (serialized per account by a mutex): open a fresh chat, type the
 * prompt, and send. The page does the login/PoW and fires /chat/completion; the
 * fetch hook (installed via addInitScript in browser.ts) tees the SSE chunks back
 * here keyed by account id, which we parse into typed events.
 *
 * The SSE PARSER is best-effort. Set DEEPSEEK_DEBUG=1 to log raw chunks and the
 * URLs the page requests, so the parser/selectors can be locked to the real site.
 */

import { getPage, getMutex, isLoggedIn, DS_URL } from './browser.ts'
import { registerSink, unregisterSink } from './tee.ts'

const DEBUG = process.env.DEEPSEEK_DEBUG === '1'
const RESPONSE_TIMEOUT_MS = 180000
const STALL_TIMEOUT_MS = 60000

export type DSEvent =
  | { type: 'content'; text: string }
  | { type: 'reasoning'; text: string }
  | { type: 'error'; message: string }

async function submitPrompt(page: any, prompt: string): Promise<void> {
  const textareaSel = '#chat-input, textarea'
  const ta = await page.$(textareaSel)
  if (ta) {
    await ta.click().catch(() => {})
    await page.fill(textareaSel, prompt)
  } else {
    const ce = await page.$('[contenteditable="true"]')
    if (!ce) throw new Error('DeepSeek input not found (tried #chat-input, textarea, [contenteditable])')
    await ce.click().catch(() => {})
    await page.evaluate((text: string) => {
      const el = document.querySelector('[contenteditable="true"]') as HTMLElement | null
      if (el) {
        el.textContent = text
        el.dispatchEvent(new Event('input', { bubbles: true }))
      }
    }, prompt)
  }
  await page.waitForTimeout(250)
  // DeepSeek sends on Enter (Shift+Enter = newline). The prompt was set via fill,
  // so embedded newlines don't trigger an early send.
  await page.keyboard.press('Enter')
}

interface ParseState { lastPath: string }

// Best-effort parse of one `data: <json>` payload. Handles an OpenAI-ish shape
// and a patch-style {p,v,o} shape seen on the DeepSeek web.
function parsePayload(jsonStr: string, state: ParseState): DSEvent[] {
  const out: DSEvent[] = []
  let obj: any
  try {
    obj = JSON.parse(jsonStr)
  } catch {
    return out
  }

  const delta = obj?.choices?.[0]?.delta
  if (delta) {
    if (typeof delta.content === 'string' && delta.content) out.push({ type: 'content', text: delta.content })
    if (typeof delta.reasoning_content === 'string' && delta.reasoning_content) out.push({ type: 'reasoning', text: delta.reasoning_content })
    if (out.length) return out
  }

  if (obj && obj.v !== undefined) {
    const path: string = typeof obj.p === 'string' ? obj.p : state.lastPath
    if (typeof obj.p === 'string') state.lastPath = obj.p
    const val = obj.v
    if (typeof val === 'string') {
      if (path && path.indexOf('thinking') !== -1) out.push({ type: 'reasoning', text: val })
      else out.push({ type: 'content', text: val })
    }
  }

  return out
}

export async function* streamDeepSeek(accountId: string, prompt: string): AsyncGenerator<DSEvent> {
  const page = getPage(accountId)
  if (!page) {
    yield { type: 'error', message: `DeepSeek account not initialized: ${accountId}` }
    return
  }

  const release = await getMutex(accountId).acquire()

  // Async hand-off between the exposed callback (keyed by account id) and here.
  const pending: string[] = []
  let waiter: ((v: string | null) => void) | null = null
  let finished = false
  const push = (v: string | null) => {
    if (v === null) finished = true
    if (waiter) { const w = waiter; waiter = null; w(v) }
    else if (v !== null) pending.push(v)
  }
  const nextRaw = (): Promise<string | null> => {
    if (pending.length) return Promise.resolve(pending.shift()!)
    if (finished) return Promise.resolve(null)
    return new Promise(res => { waiter = res })
  }

  registerSink(accountId, (data: string) => {
    if (data === '__DSCTRL__DONE') { push(null); return }
    if (data.startsWith('__DSCTRL__ERR')) { push('__DSCTRL__ERR' + data.slice('__DSCTRL__ERR'.length)); return }
    if (data.startsWith('__DSCTRL__URL')) { if (DEBUG) console.log('[DeepSeek][url]', data.slice('__DSCTRL__URL'.length).trim()); return }
    push(data)
  })

  let stallTimer: NodeJS.Timeout | null = null
  let hardTimer: NodeJS.Timeout | null = null
  const armStall = () => {
    if (stallTimer) clearTimeout(stallTimer)
    stallTimer = setTimeout(() => push(null), STALL_TIMEOUT_MS)
  }

  try {
    await page.goto(`${DS_URL}/`, { waitUntil: 'domcontentloaded' }).catch(() => {})
    if (!(await isLoggedIn(page))) {
      yield { type: 'error', message: 'DeepSeek account is not logged in. Run `npm run deepseek:login` and complete the login.' }
      return
    }

    try {
      await submitPrompt(page, prompt)
    } catch (e: any) {
      yield { type: 'error', message: `Failed to submit prompt to DeepSeek UI: ${e?.message}` }
      return
    }

    hardTimer = setTimeout(() => push(null), RESPONSE_TIMEOUT_MS)
    armStall()

    const state: ParseState = { lastPath: '' }
    let buffer = ''
    let sawAny = false
    while (true) {
      const raw = await nextRaw()
      if (raw === null) break
      armStall()
      if (raw.startsWith('__DSCTRL__ERR')) {
        yield { type: 'error', message: `DeepSeek stream error: ${raw.slice('__DSCTRL__ERR'.length)}` }
        break
      }
      sawAny = true
      if (DEBUG) console.log('[DeepSeek][raw]', JSON.stringify(raw))

      buffer += raw
      const lines = buffer.split('\n')
      buffer = lines.pop() || ''
      for (const line of lines) {
        const trimmed = line.trim()
        if (!trimmed.startsWith('data:')) continue
        const payload = trimmed.slice(5).trim()
        if (!payload || payload === '[DONE]') continue
        for (const ev of parsePayload(payload, state)) yield ev
      }
    }

    if (!sawAny) {
      yield { type: 'error', message: 'No stream captured from DeepSeek. The page may not use window.fetch for /chat/completion, or the send did not fire. Run with DEEPSEEK_DEBUG=1 to see the requested URLs.' }
    }
  } finally {
    if (stallTimer) clearTimeout(stallTimer)
    if (hardTimer) clearTimeout(hardTimer)
    unregisterSink(accountId)
    release()
  }
}
